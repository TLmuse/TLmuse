#!/bin/bash

args=$@
is_sh_ver=v4.18

. /etc/v2ray/sh/src/init.sh
